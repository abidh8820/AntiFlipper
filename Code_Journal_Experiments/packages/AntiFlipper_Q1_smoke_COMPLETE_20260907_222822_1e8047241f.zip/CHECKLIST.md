# Experiment checklist — smoke

Updated: 2026-09-07T16:28:21.616030+00:00

Progress: **1/1 complete**, 0 failed, 0 interrupted, 0 running.

A checked item has a valid completed state file. Re-running the launcher skips it. Interrupted jobs resume from `checkpoint.pt`.

| Done | # | Experiment | Dataset | Split | Method | Seed | Status |
|---|---:|---|---|---|---|---:|---|
| [x] | 1 | smoke | SYNTHETIC | IID | antiflipper | 7 | completed |
