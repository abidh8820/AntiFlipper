param(
    [ValidateSet("smoke", "core", "full")]
    [string]$Profile = "core",
    [string]$Python = $env:ANTIFLIPPER_PYTHON
)

$ErrorActionPreference = "Stop"
$PipelineRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $PipelineRoot

if (-not $Python) {
    $WorkspacePython = Join-Path (Split-Path -Parent $PipelineRoot) ".venv\Scripts\python.exe"
    if (Test-Path -LiteralPath $WorkspacePython) {
        $Python = $WorkspacePython
    } else {
        $Python = "python"
    }
}

try {
    & $Python -c "import sys; print(sys.executable)"
} catch {
    throw "A working Python environment was not found. Activate the same environment used by your notebooks, or set ANTIFLIPPER_PYTHON to its python.exe path."
}
if ($LASTEXITCODE -ne 0) {
    throw "Python failed to start. Activate your ML environment or set ANTIFLIPPER_PYTHON."
}

& $Python -c "import torch, torchvision, numpy, sklearn, scipy, matplotlib, hdbscan; print('Dependencies OK; CUDA:', torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) {
    throw "Dependencies are missing. Run: python -m pip install -r requirements.txt (install the correct CUDA PyTorch build first)."
}

& $Python cli.py plan --profile $Profile
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$TimingFile = Join-Path $PipelineRoot "analysis\$Profile\timing\fixed_workload_timing.csv"
if (-not (Test-Path -LiteralPath $TimingFile)) {
    & $Python cli.py benchmark --profile $Profile
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "The fixed-workload benchmark failed; experiment execution will continue and the error can be investigated separately."
    }
}
& $Python cli.py run --profile $Profile
exit $LASTEXITCODE
